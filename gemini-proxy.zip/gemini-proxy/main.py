# gemini-proxy/main.py
import os, requests, flask

app = flask.Flask(__name__)
GEMINI_KEY = os.environ["GEMINI_KEY"]     # set in Cloud Run console

@app.route("/", methods=["POST"])
def relay():
    r = requests.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-2.5-flash:generateContent?key={GEMINI_KEY}",
        headers={"Content-Type": "application/json"},
        data=flask.request.data,
        timeout=60,
    )
    return (r.content, r.status_code, {"Content-Type": "application/json"})
